
<div class="top_menu" id="top_menu">
	<ul>
	<li><a href="<?php echo $pe['host_root'] ?>"><i class="top_tb1"></i><span>Trang đầu</span></a></li>
	<li><a href="<?php echo pe_url('category-list') ?>"><i class="top_tb2"></i><span>Phân loại</span></a></li>
	<li><a href="<?php echo pe_url('cart') ?>"><i class="top_tb3"></i><span>Giỏ hàng</span></a></li>
	<li><a href="<?php echo $pe['host_root'] ?>user.php"><i class="top_tb4"></i><span>của tôi</span></a></li>
	</ul>
	<div class="clear"></div>
</div>