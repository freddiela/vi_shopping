<script type="text/javascript">
pe_loadscript("<?php echo $pe['host_root'] ?>api.php?mod=cron"); //
</script>
<style type="text/css">
body{background:#fff;}
</style>
</body>
</html>