<style type="text/css">
.right_bottom{padding:0;border:0;border-top:1px solid #f1f1f1;padding-top:10px}
#fabu_btn{position:fixed; display:block; bottom:0; left:0; height:40px; line-height:40px; width:100%;  text-align:center; background:#fff; padding-bottom:10px}
#fabu_btn a{background:#f8f8f8; color:#666; font-size:15px; display:block; border-radius:20px; margin:0 15px; border:1px solid #ddd}
#fabu_btn:hover{color:#fff}
</style>
</body>
</html>