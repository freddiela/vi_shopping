<?php
return unserialize('a:0:{}');
?>