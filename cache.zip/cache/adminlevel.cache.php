<?php
return unserialize('a:1:{i:1;a:4:{s:13:"adminlevel_id";s:1:"1";s:15:"adminlevel_name";s:12:"总管理员";s:17:"adminlevel_modact";s:0:"";s:19:"adminlevel_menumark";s:0:"";}}');
?>