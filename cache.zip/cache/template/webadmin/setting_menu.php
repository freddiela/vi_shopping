<div class="now">
	<a href="webadmin.php?mod=setting&act=base" <?php if($mod=='setting' && $act=='base'):?>class="sel"<?php endif;?>>网站设置<i></i></a>
	<a href="webadmin.php?mod=setting&act=user" <?php if($mod=='setting' && $act=='user'):?>class="sel"<?php endif;?>>会员设置<i></i></a>
	<a href="webadmin.php?mod=setting&act=point" <?php if($mod=='setting' && $act=='point'):?>class="sel"<?php endif;?>>积分设置<i></i></a>
	<a href="webadmin.php?mod=express" <?php if($mod=='express'):?>class="sel"<?php endif;?>>运单模板<i></i></a>
	<a href="webadmin.php?mod=setting&act=sms" <?php if($mod=='setting' && $act=='sms'):?>class="sel"<?php endif;?>>短信设置<i></i></a>
	<!--<a href="webadmin.php?mod=setting&act=email" <?php if($mod=='setting' && $act=='email'):?>class="sel"<?php endif;?>>邮箱设置<i></i></a>-->
	<div class="clear"></div>
</div>
