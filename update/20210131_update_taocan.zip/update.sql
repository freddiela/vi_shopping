ALTER TABLE `hq_huodong` ADD `huodong_price` DECIMAL( 10, 2 ) NULL DEFAULT '0';
ALTER TABLE `hq_huodong` ADD `huodong_pic` VARCHAR( 255 ) NULL AFTER `huodong_price` ;