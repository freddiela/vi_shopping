<?php
$menumark = 'order_recovery';
switch($act) {
	//####################// 回收申请 //####################//
	case 'add':
        if (isset($_p_pesubmit)) {
            $user_name = $_p_info['user_name'];
            $user_tname = $_p_info['user_tname'];
            $order_id = $_p_info['order_id'];
            $amount = $_p_info['amount'];
            $sql_set = [
                'user_id' => $_s_user_id,
                'user_tname' => $user_tname,
                'user_name' => $user_name,
                'amount' => $amount,
                'order_id' => $order_id
            ];
            if ($db->pe_insert('order_recovery', pe_dbhold($sql_set))) {
                pe_jsonshow(array('result'=>true, 'show'=>'申请已提交'));
            }
            else {
                pe_jsonshow(array('result'=>false, 'show'=>'提交失败'));
            }
        }
	break;
    //####################// 获取订单 //####################//
    case 'validate':
        $order_id = $_g_id;
        $order = $db->pe_select('order', array('order_id'=>$order_id, 'order_pstate' => 1));
        if(!$order){
            pe_jsonshow(array('code'=> 400, 'msg'=>'对不起，找不到您的可回收的订单'));
        }
        $order_recovery = $db->pe_select('order_recovery', array('order_id'=>$order_id));
        if($order_recovery){
            pe_jsonshow(array('code'=> 400, 'msg'=>'订单已回收了，不能再回收了'));
        }
        $orderdata = $db->pe_selectall('orderdata', array('order_id'=>$order_id),'product_id,product_num');
        if($orderdata){
            $product_rmoney = 0;
            foreach ($orderdata as $v){
                $product = $db->pe_select('product', array('product_id'=>$v['product_id']),'product_rmoney');
                $product_rmoney += bcmul($product['product_rmoney'],$v['product_num'],2);
            }
        }
        $res = [
            'code' => 200,
            'data' => [
                'user_name' => $order['user_name'],
                'user_tname' => $order['user_tname'],
                'money' => pe_num($product_rmoney,'round', 2, true)
            ]
        ];
        pe_jsonshow($res);
        break;
	//####################// 回收列表 //####################//
	default:
        $info_list = $db->pe_selectall('order_recovery', array('user_id'=>$_s_user_id, 'order by'=>'`id` desc'), '*', array(20, $_g_page));
		$seo = pe_seo($menutitle='回收记录');
		include(pe_tpl('order_recovery.html'));
	break;
}
?>